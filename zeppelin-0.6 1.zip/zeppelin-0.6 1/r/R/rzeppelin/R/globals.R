lEtTeRs <- c(letters,LETTERS)
alphabet <- c(lEtTeRs,0:9)

