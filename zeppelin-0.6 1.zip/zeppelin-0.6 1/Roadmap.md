
# Zeppelin Roadmap

Please check https://cwiki.apache.org/confluence/display/ZEPPELIN/Zeppelin+Roadmap for details